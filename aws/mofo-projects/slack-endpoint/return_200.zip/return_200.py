def handler(event, context):

    response = {
        'statusCode': '200'
    }

    return response
